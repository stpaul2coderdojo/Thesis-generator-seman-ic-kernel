
from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential
import openai

# Set up your Azure and OpenAI credentials
azure_key = "your_azure_key"
azure_endpoint = "your_azure_endpoint"
openai_api_key = "your_openai_api_key"

# Initialize clients
azure_client = TextAnalyticsClient(endpoint=azure_endpoint, credential=AzureKeyCredential(azure_key))
openai.api_key = openai_api_key

thesis_outline = {
    "title": "Godel’s God: A Mathematical and Philosophical Inquiry into the Ontological Proof of Divine Existence",
    "chapters": [
        {"title": "Introduction", "content": ""},
        {"title": "Historical Context", "content": ""},
        {"title": "Godel’s Ontological Proof", "content": ""},
        {"title": "Mathematical Foundations", "content": ""},
        {"title": "Philosophical Implications", "content": ""},
        {"title": "Asymptotics and Incompleteness", "content": ""},
        {"title": "The Minimum Viable Theology", "content": ""},
        {"title": "Comparative Analysis", "content": ""},
        {"title": "Critiques and Counterarguments", "content": ""},
        {"title": "Conclusion", "content": ""}
    ]
}

def generate_section_content(section_title):
    prompt = f"Write a detailed section for a thesis on the topic: {section_title}"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=1500
    )
    return response.choices[0].text

for chapter in thesis_outline["chapters"]:
    chapter["content"] = generate_section_content(chapter["title"])

thesis_content = f"Title: {thesis_outline['title']}

"
for chapter in thesis_outline["chapters"]:
    thesis_content += f"Chapter: {chapter['title']}

{chapter['content']}

"

with open("thesis_draft.txt", "w") as file:
    file.write(thesis_content)
    