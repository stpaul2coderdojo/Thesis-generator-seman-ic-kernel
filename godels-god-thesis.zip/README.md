
# Godel's God Thesis Generator

This project generates a thesis based on Godel's ontological proof using Microsoft Semantic Kernel and OpenAI's GPT model.

## Setup

1. Install dependencies:
    ```sh
    pip install -r requirements.txt
    ```

2. Set up your Azure and OpenAI credentials in `thesis_generator.py`.

3. Run the script:
    ```sh
    python thesis_generator.py
    ```

The generated thesis will be saved as `thesis_draft.txt`.
    